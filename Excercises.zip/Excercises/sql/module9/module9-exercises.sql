/* ============================================================
   CHAPTER 8: VIEWS
   ============================================================ */

-- 8.1
-- Create a view called vw_title_authors that shows
-- the title name, and the author's first and last name.
-- Also include the author's state so it can be filtered on.
-- Hint: You will need to join titles, titleauthor, and authors.



-- 8.2
-- Use the view vw_title_authors to list all titles
-- written by authors from California.



-- 8.3
-- Create a view called vw_publisher_sales that shows
-- each publisher's name and their total year-to-date
-- sales across all their titles.
-- Hint: Join publishers and titles, then GROUP BY publisher.



-- 8.4
-- Query vw_publisher_sales to find the publisher
-- with the highest total sales.



-- 8.5
-- Use CREATE OR REPLACE VIEW to update vw_publisher_sales
-- to also include the count of titles per publisher
-- alongside the total sales figure.



-- 8.6
-- Create a view called vw_store_performance that shows:
--   - Store name
--   - Total quantity of books sold
--   - Total revenue (quantity * title price)
-- Hint: Join stores, sales, and titles.



-- 8.7
-- Drop the view vw_title_authors.




/* ============================================================
   CHAPTER 9: STORED PROCEDURES
   ============================================================ */

-- 9.1
-- Create a stored procedure called sp_get_all_titles
-- that returns all rows from the titles table.
-- Then CALL it.



-- 9.2
-- Create a stored procedure called sp_titles_by_type
-- that accepts a book type as an IN parameter and
-- returns all titles of that type.
-- Test it with the type 'business'.



-- 9.3
-- Create a stored procedure called sp_pub_title_count
-- that accepts a publisher ID as an IN parameter and
-- returns the number of titles for that publisher
-- via an OUT parameter.
-- Test it with pub_id '0736'.



-- 9.4
-- Create a stored procedure called sp_price_band that
-- accepts a title_id as an IN parameter and returns a
-- price category using IF / ELSEIF / ELSE:
--   'Budget'   -- price under $10.00
--   'Standard' -- price between $10.00 and $20.00
--   'Premium'  -- price above $20.00
-- Test it with a few different title IDs.



-- 9.5
-- Create a stored procedure called sp_discounted_price
-- that accepts a title_id as an IN parameter and:
--   - Declares a local variable for a discount rate (use 0.15)
--   - Returns the title's original price and discounted price
-- Test it.



-- 9.6
-- Drop the stored procedure sp_get_all_titles.