* ============================================================
   CHAPTER 9: STORED PROCEDURES
   ============================================================ */

USE pubs;

-- 9.1
-- Create a stored procedure called sp_get_all_titles
-- that returns all rows from the titles table.

DELIMITER $$
CREATE PROCEDURE sp_get_all_titles()
BEGIN
    SELECT * FROM titles;
END$$
DELIMITER ;

CALL sp_get_all_titles();


-- 9.2
-- Create a stored procedure called sp_titles_by_type
-- that accepts a book type as an IN parameter.

DELIMITER $$
CREATE PROCEDURE sp_titles_by_type(IN p_type CHAR(12))
BEGIN
    SELECT * FROM titles
    WHERE  type = p_type;
END$$
DELIMITER ;

CALL sp_titles_by_type('business');


-- 9.3
-- Create a stored procedure called sp_pub_title_count
-- that accepts a publisher ID (IN) and returns the
-- number of titles for that publisher via an OUT parameter.

DELIMITER $$
CREATE PROCEDURE sp_pub_title_count(
    IN  p_pub_id CHAR(4),
    OUT p_count  INT
)
BEGIN
    SELECT COUNT(*) INTO p_count
    FROM   titles
    WHERE  pub_id = p_pub_id;
END$$
DELIMITER ;

CALL sp_pub_title_count('0736', @cnt);
SELECT @cnt AS title_count;


-- 9.4
-- Create a stored procedure called sp_price_band that
-- accepts a title_id and returns a price category.

DELIMITER $$
CREATE PROCEDURE sp_price_band(IN p_title_id VARCHAR(6))
BEGIN
    DECLARE v_price    DECIMAL(8,2);
    DECLARE v_category VARCHAR(20);

    SELECT price INTO v_price
    FROM   titles
    WHERE  title_id = p_title_id;

    IF v_price < 10.00 THEN
        SET v_category = 'Budget';
    ELSEIF v_price <= 20.00 THEN
        SET v_category = 'Standard';
    ELSE
        SET v_category = 'Premium';
    END IF;

    SELECT p_title_id  AS title_id,
           v_price     AS price,
           v_category  AS category;
END$$
DELIMITER ;

CALL sp_price_band('BU1032');  -- 11.95 -> Standard
CALL sp_price_band('PC8888');  --  7.99 -> Budget
CALL sp_price_band('TC4203');  -- 11.95 -> Standard


-- 9.5
-- Create a stored procedure called sp_discounted_price
-- that uses a declared variable for a 15% discount rate.

DELIMITER $$
CREATE PROCEDURE sp_discounted_price(IN p_title_id VARCHAR(6))
BEGIN
    DECLARE v_discount DECIMAL(4,2);
    SET v_discount = 0.15;

    SELECT title_id,
           title,
           price                                AS original_price,
           ROUND(price * (1 - v_discount), 2)  AS discounted_price
    FROM   titles
    WHERE  title_id = p_title_id;
END$$
DELIMITER ;

CALL sp_discounted_price('BU1032');


-- 9.6
-- Drop the stored procedure sp_get_all_titles.

DROP PROCEDURE IF EXISTS sp_get_all_titles;