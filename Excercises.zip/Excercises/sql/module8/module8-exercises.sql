/* ============================================================
   CHAPTER 8: VIEWS
   ============================================================ */

-- 8.1
-- Create a view called vw_title_authors that shows
-- the title name, and the author's first and last name.
-- Also include the author's state so it can be filtered on.
-- Hint: You will need to join titles, titleauthor, and authors.



-- 8.2
-- Use the view vw_title_authors to list all titles
-- written by authors from California.



-- 8.3
-- Create a view called vw_publisher_sales that shows
-- each publisher's name and their total year-to-date
-- sales across all their titles.
-- Hint: Join publishers and titles, then GROUP BY publisher.



-- 8.4
-- Query vw_publisher_sales to find the publisher
-- with the highest total sales.



-- 8.5
-- Use CREATE OR REPLACE VIEW to update vw_publisher_sales
-- to also include the count of titles per publisher
-- alongside the total sales figure.



-- 8.6
-- Create a view called vw_store_performance that shows:
--   - Store name
--   - Total quantity of books sold
--   - Total revenue (quantity * title price)
-- Hint: Join stores, sales, and titles.



-- 8.7
-- Drop the view vw_title_authors.