
/* ============================================================
   CHAPTER 8: VIEWS
   ============================================================ */

USE pubs;

-- 8.1
-- Create a view called vw_title_authors that shows
-- the title name, and the author's first and last name.
-- Also include the author's state so it can be filtered on.

CREATE VIEW vw_title_authors AS
SELECT t.title_id,
       t.title,
       a.au_fname,
       a.au_lname,
       a.state AS au_state
FROM   titles      t
JOIN   titleauthor ta ON t.title_id = ta.title_id
JOIN   authors     a  ON ta.au_id   = a.au_id;


-- 8.2
-- Use the view vw_title_authors to list all titles
-- written by authors from California.

SELECT title, au_fname, au_lname
FROM   vw_title_authors
WHERE  au_state = 'CA';


-- 8.3
-- Create a view called vw_publisher_sales that shows
-- each publisher's name and their total year-to-date
-- sales across all their titles.

CREATE VIEW vw_publisher_sales AS
SELECT p.pub_id,
       p.pub_name,
       SUM(t.ytd_sales) AS total_sales
FROM   publishers p
JOIN   titles     t ON p.pub_id = t.pub_id
GROUP BY p.pub_id, p.pub_name;


-- 8.4
-- Query vw_publisher_sales to find the publisher
-- with the highest total sales.

SELECT pub_name, total_sales
FROM   vw_publisher_sales
ORDER  BY total_sales DESC
LIMIT  1;


-- 8.5
-- Use CREATE OR REPLACE VIEW to update vw_publisher_sales
-- to also include the count of titles per publisher.

CREATE OR REPLACE VIEW vw_publisher_sales AS
SELECT p.pub_id,
       p.pub_name,
       SUM(t.ytd_sales)  AS total_sales,
       COUNT(t.title_id) AS title_count
FROM   publishers p
JOIN   titles     t ON p.pub_id = t.pub_id
GROUP BY p.pub_id, p.pub_name;


-- 8.6
-- Create a view called vw_store_performance that shows
-- store name, total quantity sold, and total revenue.

CREATE VIEW vw_store_performance AS
SELECT s.stor_name,
       SUM(sa.qty)           AS total_qty_sold,
       SUM(sa.qty * t.price) AS total_revenue
FROM   stores s
JOIN   sales  sa ON s.stor_id   = sa.stor_id
JOIN   titles t  ON sa.title_id = t.title_id
GROUP BY s.stor_id, s.stor_name;


-- 8.7
-- Drop the view vw_title_authors.

DROP VIEW IF EXISTS vw_title_authors;
